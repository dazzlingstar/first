<?php
//$mysqli = new mysqli("localhost","user","password","dbname");
try{
	//1.$pdo = new PDO("mysql:host=localhost;dbname=hyerp","root","");
	//2.$pdo = new PDO("uri:mysqlPdo.ini","root","");
	//3.$pdo = new PDO("mysqlpdo","root","");
	$pdo = new PDO("mysqlpdo","root","");
	$pdo->setAttribute(PDO::ATTR_AUTOCOMMIT,0);
}catch(PDOException $e){
	die("数据库连接失败".$e->getMessage());
}
echo $pdo->getAttribute(PDO::ATTR_AUTOCOMMIT );

//print_r($pdo);