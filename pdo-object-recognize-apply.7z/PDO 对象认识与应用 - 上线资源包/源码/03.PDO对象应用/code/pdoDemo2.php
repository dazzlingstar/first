<?php
//1.连接数据库
try{
	$pdo = new PDO("mysql:host=localhost;dbname=jikexueyuan","root","");
}catch(PDOException $e){
	die("数据库连接失败".$e->getMessage());
}

//这是一种快捷的方法
/* $sql = "select * from stu";
foreach($pdo->query($sql) as $val){
	echo $val['id']."-----".$val['name']."<br>";
} */

//$sql = "insert into stu values(null,'oracle','w',44)";
//$sql = "delete from stu where id=11";
$sql = "update stu set name='js' where id=3";
$res = $pdo->exec($sql);
if($res){
	echo "success";
}

